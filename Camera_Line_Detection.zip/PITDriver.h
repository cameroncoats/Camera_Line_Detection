// Cameron Coats / Group 3
// EN0627 / NXP Car
// 
// Periodic Interrupt Timer Driver
#ifndef PITDriver
  #define PITDriver
void PITInit(void);
#endif

