// Cameron Coats / Group 3
// EN0627 NXP Car
// 
// Main (Centerline detection only)

#include "MKL25Z4.h"
#include "stdio.h"
#include "main.h"
#include "TFCHandler.h"
#include "UARTHandler.h"

// set initial state
MainState State = INIT;

int main(void){
	
	while(1){
		char stringBuffer[128];
		switch(State){
			case INIT:
				// Enable ports etc
				initPorts();
				// Setup UART
				initialiseUART0();
			  // Setup Camera
				initCameraDriver();
				// setup PIT
			  initPIT();
				// setup servo
				//initServo();
				// Send power on message
				sendString("> Init\n");
				// Go to wait state
				State = AUTOEXPOSURE;
			break;
		  case WAIT_PRESS:
				// Wait for pushbutton A
				if((GPIOC_PDIR & 1<<13) != 0){
					// Do line detection
				  State = DO_LINESCAN;
				}
			break;
			case DO_LINESCAN:
				// Get line position (CameraHandler.c)
				linePos = getLineOffset();
		    // Format into string
			sprintf(stringBuffer,"> Line: %d \nP0: %d\nP1: %d\nB: %d\nMin/Max: %d - %d\n Ex: %d \n",linePos,POT0_Value,POT1_Value,BATT_Value,minValue,maxValue,bestExposureTime);
			  // Send string over UART
			  sendString(stringBuffer);
				// Return to wait state
			  State = WAIT_RELEASE;
			break;
			case WAIT_RELEASE:
				if((GPIOC_PDIR & 1<<13) == 0){
				State = WAIT_PRESS;
				}
			break;
			case AUTOEXPOSURE:
				sendString("> AutoExp\n");
				doAutoExposure = true;
				State = WAIT_AUTOEXPOSURE;
			break;
			case WAIT_AUTOEXPOSURE:
				while(!autoexposureDone){}
				 // Format into string
					sprintf(stringBuffer,"> Done\n Time: %d Score: %d \n",bestExposureTime,bestScore);
			  // Send string over UART
			  sendString(stringBuffer);
				State = WAIT_PRESS;
			break;
			default:
				State = WAIT_PRESS;
			break;
		}
  }
}
