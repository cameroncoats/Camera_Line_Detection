// Cameron Coats / Group 3
// EN0627 / NXP Car
// 
// Servo Driver using Timer 1

#include "MKL25Z4.h"
#include "ServoDriver.h"

void initServo(void){
	 // Disable timer
	 TPM1->SC = 0;  
	// Enable TPM1 Clock
  SIM_SCGC6 |= SIM_SCGC6_TPM1_MASK;
	
	// use MCGFLL for timers
	SIM->SOPT2 |= 0x01000000;
	
	// Set start value
	TPM1->CNT = 0;
	// Set prescale & modulo for t=20ms
	TPM1->MOD = 0xFFFF;

	// set up output compare
	// servo is port B bit 0 -> TPM1_CH0
	// edge aligned, non inverted
	TPM1->CONTROLS[0].CnSC = 0x20 | 0x08;
	// Initial value is 1.5ms = center servo
	TPM1->CONTROLS[0].CnV = 0x8000;
	
	
	// Ensure TOF is not set
	TPM1->SC &= 0xFF7F;
	
	// Start Timer
	TPM1->SC |= 1<< 3 | 1U<<1 | 1U;
	
}
