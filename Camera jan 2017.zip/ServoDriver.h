// Cameron Coats / Group 3
// EN0627 / NXP Car
// 
// Servo Driver using Timer 1

#ifndef ServoDriver
  #define ServoDriver
void initServo(void);

void TPM1_IRQHandler(void);
extern signed short getLineOffset(void);

#endif
