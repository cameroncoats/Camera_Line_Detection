// Cameron Coats / Group 3
// EN0627 / NXP Car
// 
// Main
#include <stdbool.h>
#ifndef Main
  #define Main

	extern signed short getLineOffset(void);
	extern void initCameraDriver(void);
	extern void initPIT(void);
	extern void initServo(void);
	extern void setLEDs(unsigned char);
	int main(void);

	typedef enum {INIT, WAIT_PRESS, WAIT_RELEASE, DO_LINESCAN, AUTOEXPOSURE, WAIT_AUTOEXPOSURE} MainState;

	bool doAutoExposure = false;
	extern bool autoexposureDone;
	short signed int linePos;
	
	extern int bestExposureTime;
	extern unsigned int bestScore;
	extern unsigned short int POT0_Value, POT1_Value, BATT_Value;
	extern short int maxValue,minValue;
#endif
